
//bubble create
function makeBubble(){
    var clutter ="";
for(var i=1;i<=500;i++){
    var ren = Math.floor(Math.random()*10)
    clutter +=`  <div class="bubble">${ren}</div>`

}
document.querySelector(".p-btm").innerHTML=clutter;
}
// timer
var timer = 60;
function runTimer(){
   var timerin = setInterval(function(){
        if(timer>0){
            timer--;
            document.querySelector("#Timerval").textContent=timer;
        }
        else{
            clearIntervala(timerin);
            document.querySelector(".p-btm").innerHTML="";
        }

    },1000)
}
//hit
var HIt =0;
function getHit(){
    Hit = Math.floor(Math.random()*10)
    document.querySelector("#Hit").textContent = Hit;
}

function increaseScore(){
    score="";
    document.querySelector("#score").textContent = (+10);
}
//eventlistener for bubble
document.querySelector(".p-btm")
.addEventListener("click",function(dets){
    var clicknum = Number(dets.target.textContent);
    if(clicknum === Hit){
        increaseScore();
        makeBubble();
        getHit();
    }
})
runTimer();
makeBubble();
getHit();



